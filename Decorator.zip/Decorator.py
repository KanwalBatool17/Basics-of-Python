def Phone_num(given_num):

    def square():
        x = (given_num * given_num)
        return x
    return square()

def input(num):
    return num

print(Phone_num(given_num= 6))







